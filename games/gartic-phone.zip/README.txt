Gartic Phone - Simple GitHub Pages version

Files to copy into your existing repo:

games/gartic-phone/index.html
games/gartic-phone/style.css
games/gartic-phone/game.js

Your existing GameHub folder detector should automatically discover this folder as a category.

This prototype uses Supabase Realtime Presence for the player list and Broadcast for game events.
No database table or SQL setup is required for the public-room prototype.

Important:
- Keep the supplied publishable key in frontend code only; never replace it with a secret/service-role key.
- For production, add Realtime Authorization/RLS and stronger server-side validation.
- The host is authoritative for round state. The host should stay connected during a game.
